﻿var sitemap = 

(function() {
    var _ = function() { var r={},a=arguments; for(var i=0; i<a.length; i+=2) r[a[i]]=a[i+1]; return r; }
    var _creator = function() { return _(b,[_(c,d,e,f,g,h,i,[_(c,j,e,f,g,k),_(c,l,e,f,g,m),_(c,n,e,f,g,o)])]);}; 
var b="rootNodes",c="pageName",d="清單顯示",e="type",f="Wireframe",g="url",h="清單顯示.html",i="children",j="素材",k="素材.html",l="色塊顯示",m="色塊顯示.html",n="Page 3",o="Page_3.html";
return _creator();
})();
