for(var i = 0; i < 25; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u3'] = 'top';document.getElementById('u21_img').tabIndex = 0;

u21.style.cursor = 'pointer';
$axure.eventManager.click('u21', function(e) {

if (true) {

	SetPanelVisibility('u6','hidden','none',500);

}
});
gv_vAlignTable['u16'] = 'center';gv_vAlignTable['u12'] = 'top';document.getElementById('u4_img').tabIndex = 0;

u4.style.cursor = 'pointer';
$axure.eventManager.click('u4', function(e) {

if (true) {

	SetPanelVisibility('u6','','none',500);

	NewTab($axure.globalVariableProvider.getLinkUrl('銀聯付款.html'), "");

}
});
gv_vAlignTable['u8'] = 'center';gv_vAlignTable['u10'] = 'center';document.getElementById('u17_img').tabIndex = 0;

u17.style.cursor = 'pointer';
$axure.eventManager.click('u17', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('訂單明細.html');

}
});
gv_vAlignTable['u22'] = 'center';gv_vAlignTable['u5'] = 'center';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u14'] = 'center';gv_vAlignTable['u20'] = 'center';document.getElementById('u23_img').tabIndex = 0;

u23.style.cursor = 'pointer';
$axure.eventManager.click('u23', function(e) {

if (true) {

}
});
gv_vAlignTable['u24'] = 'center';gv_vAlignTable['u18'] = 'center';