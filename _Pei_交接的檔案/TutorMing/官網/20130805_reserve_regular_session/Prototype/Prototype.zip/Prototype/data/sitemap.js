﻿var sitemap = 

(function() {
    var _ = function() { var r={},a=arguments; for(var i=0; i<a.length; i+=2) r[a[i]]=a[i+1]; return r; }
    var _creator = function() { return _(b,[_(c,d,e,f,g,h,i,[_(c,j,e,f,g,k),_(c,l,e,f,g,m)])]);}; 
var b="rootNodes",c="pageName",d="Version1",e="type",f="Wireframe",g="url",h="Version1.html",i="children",j="Version2",k="Version2.html",l="參考資料",m="參考資料.html";
return _creator();
})();
