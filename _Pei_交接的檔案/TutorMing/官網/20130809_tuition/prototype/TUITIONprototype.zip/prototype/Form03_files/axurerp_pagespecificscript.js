for(var i = 0; i < 66; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u21'] = 'center';gv_vAlignTable['u51'] = 'center';gv_vAlignTable['u25'] = 'top';
$axure.eventManager.mouseover('u46', function(e) {
if (!IsTrueMouseOver('u46',e)) return;
if (true) {

	SetPanelState('u40', 'pd0u40','none','',500,'swing','down',200);

}
});

$axure.eventManager.mouseout('u46', function(e) {
if (!IsTrueMouseOut('u46',e)) return;
if (true) {

	SetPanelVisibility('u40','hidden','none',500);

}
});
gv_vAlignTable['u31'] = 'top';gv_vAlignTable['u38'] = 'top';gv_vAlignTable['u32'] = 'top';gv_vAlignTable['u23'] = 'top';gv_vAlignTable['u62'] = 'center';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u27'] = 'top';gv_vAlignTable['u7'] = 'center';gv_vAlignTable['u30'] = 'top';gv_vAlignTable['u34'] = 'center';gv_vAlignTable['u17'] = 'center';gv_vAlignTable['u64'] = 'center';gv_vAlignTable['u19'] = 'center';gv_vAlignTable['u49'] = 'center';gv_vAlignTable['u11'] = 'center';gv_vAlignTable['u15'] = 'center';gv_vAlignTable['u45'] = 'top';gv_vAlignTable['u36'] = 'center';
$axure.eventManager.mouseover('u58', function(e) {
if (!IsTrueMouseOver('u58',e)) return;
if (true) {

	SetPanelState('u60', 'pd0u60','none','',500,'swing','down',200);

}
});

$axure.eventManager.mouseout('u58', function(e) {
if (!IsTrueMouseOut('u58',e)) return;
if (true) {

	SetPanelVisibility('u60','hidden','none',500);

}
});
gv_vAlignTable['u37'] = 'top';gv_vAlignTable['u22'] = 'top';gv_vAlignTable['u13'] = 'center';gv_vAlignTable['u3'] = 'center';gv_vAlignTable['u47'] = 'center';
$axure.eventManager.mouseover('u50', function(e) {
if (!IsTrueMouseOver('u50',e)) return;
if (true) {

	SetPanelState('u52', 'pd0u52','none','',500,'swing','down',200);

}
});

$axure.eventManager.mouseout('u50', function(e) {
if (!IsTrueMouseOut('u50',e)) return;
if (true) {

	SetPanelVisibility('u52','hidden','none',500);

}
});
gv_vAlignTable['u24'] = 'top';gv_vAlignTable['u54'] = 'center';gv_vAlignTable['u39'] = 'top';gv_vAlignTable['u26'] = 'top';gv_vAlignTable['u65'] = 'top';gv_vAlignTable['u56'] = 'center';gv_vAlignTable['u5'] = 'center';gv_vAlignTable['u9'] = 'center';gv_vAlignTable['u42'] = 'center';gv_vAlignTable['u57'] = 'top';gv_vAlignTable['u44'] = 'center';gv_vAlignTable['u29'] = 'center';gv_vAlignTable['u59'] = 'center';