for(var i = 0; i < 76; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u25'] = 'top';gv_vAlignTable['u16'] = 'center';gv_vAlignTable['u55'] = 'top';gv_vAlignTable['u46'] = 'center';gv_vAlignTable['u31'] = 'top';gv_vAlignTable['u38'] = 'top';HookHover('u62', false);
gv_vAlignTable['u53'] = 'top';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u27'] = 'top';gv_vAlignTable['u7'] = 'center';HookHover('u66', false);
gv_vAlignTable['u30'] = 'top';HookHover('u60', false);
HookHover('u64', false);
gv_vAlignTable['u19'] = 'top';gv_vAlignTable['u11'] = 'center';gv_vAlignTable['u41'] = 'top';gv_vAlignTable['u71'] = 'center';gv_vAlignTable['u36'] = 'top';gv_vAlignTable['u75'] = 'center';gv_vAlignTable['u37'] = 'top';gv_vAlignTable['u13'] = 'top';gv_vAlignTable['u52'] = 'center';gv_vAlignTable['u3'] = 'center';gv_vAlignTable['u73'] = 'center';gv_vAlignTable['u20'] = 'top';gv_vAlignTable['u50'] = 'center';gv_vAlignTable['u24'] = 'center';gv_vAlignTable['u69'] = 'center';gv_vAlignTable['u61'] = 'center';gv_vAlignTable['u35'] = 'center';gv_vAlignTable['u26'] = 'top';gv_vAlignTable['u65'] = 'center';gv_vAlignTable['u5'] = 'center';gv_vAlignTable['u12'] = 'top';gv_vAlignTable['u9'] = 'center';gv_vAlignTable['u42'] = 'top';gv_vAlignTable['u63'] = 'center';gv_vAlignTable['u18'] = 'center';gv_vAlignTable['u48'] = 'center';gv_vAlignTable['u67'] = 'center';gv_vAlignTable['u57'] = 'center';gv_vAlignTable['u40'] = 'center';gv_vAlignTable['u14'] = 'top';gv_vAlignTable['u29'] = 'center';gv_vAlignTable['u59'] = 'center';