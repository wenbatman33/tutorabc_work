for(var i = 0; i < 118; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u21'] = 'top';gv_vAlignTable['u102'] = 'center';gv_vAlignTable['u25'] = 'center';gv_vAlignTable['u16'] = 'top';gv_vAlignTable['u55'] = 'center';gv_vAlignTable['u46'] = 'top';gv_vAlignTable['u76'] = 'center';gv_vAlignTable['u31'] = 'center';gv_vAlignTable['u77'] = 'top';gv_vAlignTable['u38'] = 'top';gv_vAlignTable['u23'] = 'center';gv_vAlignTable['u62'] = 'center';gv_vAlignTable['u53'] = 'top';gv_vAlignTable['u87'] = 'center';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u7'] = 'center';document.getElementById('u112_img').tabIndex = 0;

u112.style.cursor = 'pointer';
$axure.eventManager.click('u112', function(e) {

if (true) {

	SetPanelVisibility('u107','hidden','none',500);

}
});
gv_vAlignTable['u115'] = 'center';gv_vAlignTable['u104'] = 'center';gv_vAlignTable['u60'] = 'top';document.getElementById('u89_img').tabIndex = 0;

u89.style.cursor = 'pointer';
$axure.eventManager.click('u89', function(e) {

if (true) {

	NewTab('http://www.tutorming.com/asp/products/tutorming.asp', "");

}
});
gv_vAlignTable['u17'] = 'top';gv_vAlignTable['u100'] = 'center';gv_vAlignTable['u19'] = 'top';document.getElementById('u103_img').tabIndex = 0;

u103.style.cursor = 'pointer';
$axure.eventManager.click('u103', function(e) {

if (true) {

	SetPanelVisibility('u107','','none',500);

}
});
gv_vAlignTable['u79'] = 'center';gv_vAlignTable['u81'] = 'center';document.getElementById('u97_img').tabIndex = 0;

u97.style.cursor = 'pointer';
$axure.eventManager.click('u97', function(e) {

if (true) {

	SetPanelVisibility('u107','','none',500);

}
});
gv_vAlignTable['u85'] = 'center';gv_vAlignTable['u11'] = 'center';gv_vAlignTable['u71'] = 'center';gv_vAlignTable['u15'] = 'center';gv_vAlignTable['u45'] = 'center';gv_vAlignTable['u36'] = 'top';gv_vAlignTable['u58'] = 'top';gv_vAlignTable['u37'] = 'top';gv_vAlignTable['u92'] = 'center';gv_vAlignTable['u83'] = 'center';document.getElementById('u95_img').tabIndex = 0;

u95.style.cursor = 'pointer';
$axure.eventManager.click('u95', function(e) {

if (true) {

	SetPanelVisibility('u107','','none',500);

}
});
gv_vAlignTable['u13'] = 'center';gv_vAlignTable['u52'] = 'center';gv_vAlignTable['u43'] = 'top';gv_vAlignTable['u3'] = 'center';gv_vAlignTable['u47'] = 'top';gv_vAlignTable['u90'] = 'top';gv_vAlignTable['u73'] = 'top';gv_vAlignTable['u20'] = 'top';gv_vAlignTable['u50'] = 'center';gv_vAlignTable['u106'] = 'center';gv_vAlignTable['u28'] = 'center';document.getElementById('u99_img').tabIndex = 0;

u99.style.cursor = 'pointer';
$axure.eventManager.click('u99', function(e) {

if (true) {

	SetPanelVisibility('u107','','none',500);

}
});
gv_vAlignTable['u113'] = 'center';gv_vAlignTable['u111'] = 'center';gv_vAlignTable['u69'] = 'center';gv_vAlignTable['u94'] = 'center';gv_vAlignTable['u96'] = 'center';document.getElementById('u91_img').tabIndex = 0;

u91.style.cursor = 'pointer';
$axure.eventManager.click('u91', function(e) {

if (true) {

	SetPanelVisibility('u107','','none',500);

}
});
gv_vAlignTable['u35'] = 'center';gv_vAlignTable['u26'] = 'top';gv_vAlignTable['u65'] = 'center';document.getElementById('u105_img').tabIndex = 0;

u105.style.cursor = 'pointer';
$axure.eventManager.click('u105', function(e) {

if (true) {

	SetPanelVisibility('u107','','none',500);

}
});
gv_vAlignTable['u109'] = 'center';gv_vAlignTable['u5'] = 'center';gv_vAlignTable['u9'] = 'center';gv_vAlignTable['u42'] = 'center';gv_vAlignTable['u33'] = 'center';gv_vAlignTable['u72'] = 'top';gv_vAlignTable['u63'] = 'top';gv_vAlignTable['u18'] = 'top';gv_vAlignTable['u48'] = 'top';gv_vAlignTable['u67'] = 'center';gv_vAlignTable['u88'] = 'top';gv_vAlignTable['u57'] = 'center';gv_vAlignTable['u40'] = 'center';gv_vAlignTable['u117'] = 'center';gv_vAlignTable['u74'] = 'top';gv_vAlignTable['u29'] = 'top';gv_vAlignTable['u59'] = 'top';gv_vAlignTable['u98'] = 'center';