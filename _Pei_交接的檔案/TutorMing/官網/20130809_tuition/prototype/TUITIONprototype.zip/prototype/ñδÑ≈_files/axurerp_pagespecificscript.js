for(var i = 0; i < 68; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u51'] = 'top';gv_vAlignTable['u16'] = 'center';gv_vAlignTable['u55'] = 'center';gv_vAlignTable['u46'] = 'center';gv_vAlignTable['u31'] = 'center';gv_vAlignTable['u38'] = 'center';HookHover('u62', false);
gv_vAlignTable['u53'] = 'top';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u27'] = 'center';gv_vAlignTable['u7'] = 'center';HookHover('u66', false);
gv_vAlignTable['u17'] = 'top';HookHover('u64', false);
gv_vAlignTable['u11'] = 'center';gv_vAlignTable['u41'] = 'center';HookHover('u58', false);
gv_vAlignTable['u22'] = 'center';gv_vAlignTable['u13'] = 'center';document.getElementById('u52_img').tabIndex = 0;

u52.style.cursor = 'pointer';
$axure.eventManager.click('u52', function(e) {

if (true) {

	NewTab('http://www.tutorming.com/asp/products/tutorming.asp', "");

}
});
gv_vAlignTable['u3'] = 'center';gv_vAlignTable['u20'] = 'center';gv_vAlignTable['u50'] = 'center';gv_vAlignTable['u28'] = 'top';gv_vAlignTable['u24'] = 'center';HookHover('u54', false);
gv_vAlignTable['u39'] = 'top';gv_vAlignTable['u61'] = 'center';gv_vAlignTable['u35'] = 'center';gv_vAlignTable['u65'] = 'center';gv_vAlignTable['u5'] = 'center';gv_vAlignTable['u9'] = 'center';gv_vAlignTable['u42'] = 'top';gv_vAlignTable['u33'] = 'center';gv_vAlignTable['u63'] = 'center';gv_vAlignTable['u18'] = 'top';gv_vAlignTable['u48'] = 'center';gv_vAlignTable['u67'] = 'center';gv_vAlignTable['u57'] = 'center';gv_vAlignTable['u44'] = 'center';gv_vAlignTable['u29'] = 'top';gv_vAlignTable['u59'] = 'center';