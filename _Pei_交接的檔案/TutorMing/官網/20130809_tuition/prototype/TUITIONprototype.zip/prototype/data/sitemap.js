﻿var sitemap = 

(function() {
    var _ = function() { var r={},a=arguments; for(var i=0; i<a.length; i+=2) r[a[i]]=a[i+1]; return r; }
    var _creator = function() { return _(b,[_(c,d,e,f,g,h,i,[_(c,j,e,f,g,k),_(c,l,e,f,g,m),_(c,n,e,f,g,o)]),_(c,p,e,f,g,q,i,[_(c,r,e,f,g,s),_(c,t,e,f,g,u),_(c,v,e,f,g,w),_(c,x,e,f,g,y),_(c,z,e,f,g,A)])]);}; 
var b="rootNodes",c="pageName",d="Form01",e="type",f="Wireframe",g="url",h="Form01.html",i="children",j="素材",k="素材.html",l="Form03",m="Form03.html",n="Page 3",o="Page_3.html",p="Form02",q="Form02.html",r="Form04",s="Form04.html",t="產品",u="產品.html",v="月份",w="月份.html",x="自由配",y="自由配.html",z="自由配2",A="自由配2.html";
return _creator();
})();
