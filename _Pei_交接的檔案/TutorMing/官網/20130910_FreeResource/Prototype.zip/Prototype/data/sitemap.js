﻿var sitemap = 

(function() {
    var _ = function() { var r={},a=arguments; for(var i=0; i<a.length; i+=2) r[a[i]]=a[i+1]; return r; }
    var _creator = function() { return _(b,[_(c,d,e,f,g,h,i,[_(c,j,e,f,g,k),_(c,l,e,f,g,m,i,[_(c,n,e,f,g,o)])])]);}; 
var b="rootNodes",c="pageName",d="Home",e="type",f="Wireframe",g="url",h="Home.html",i="children",j="Version1",k="Version1.html",l="Version2",m="Version2.html",n="Free Resource",o="Free_Resource.html";
return _creator();
})();
