for(var i = 0; i < 60; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u31'] = 'center';gv_vAlignTable['u17'] = 'center';gv_vAlignTable['u29'] = 'center';gv_vAlignTable['u21'] = 'center';gv_vAlignTable['u57'] = 'center';gv_vAlignTable['u59'] = 'center';gv_vAlignTable['u15'] = 'center';gv_vAlignTable['u13'] = 'center';gv_vAlignTable['u43'] = 'center';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u37'] = 'center';gv_vAlignTable['u41'] = 'center';gv_vAlignTable['u11'] = 'center';gv_vAlignTable['u3'] = 'center';gv_vAlignTable['u39'] = 'center';gv_vAlignTable['u9'] = 'center';gv_vAlignTable['u35'] = 'center';gv_vAlignTable['u27'] = 'center';gv_vAlignTable['u7'] = 'center';gv_vAlignTable['u23'] = 'center';gv_vAlignTable['u25'] = 'center';gv_vAlignTable['u46'] = 'top';gv_vAlignTable['u53'] = 'center';gv_vAlignTable['u19'] = 'center';gv_vAlignTable['u55'] = 'center';gv_vAlignTable['u5'] = 'center';gv_vAlignTable['u49'] = 'center';gv_vAlignTable['u47'] = 'top';gv_vAlignTable['u51'] = 'center';gv_vAlignTable['u45'] = 'center';gv_vAlignTable['u33'] = 'center';