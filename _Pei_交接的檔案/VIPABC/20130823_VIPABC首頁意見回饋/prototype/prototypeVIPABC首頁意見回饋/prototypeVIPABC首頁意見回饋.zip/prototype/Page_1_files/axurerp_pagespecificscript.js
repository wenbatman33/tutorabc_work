for(var i = 0; i < 77; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u21'] = 'center';gv_vAlignTable['u25'] = 'center';gv_vAlignTable['u46'] = 'center';gv_vAlignTable['u76'] = 'top';gv_vAlignTable['u38'] = 'center';gv_vAlignTable['u32'] = 'center';gv_vAlignTable['u23'] = 'center';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u66'] = 'center';gv_vAlignTable['u30'] = 'center';gv_vAlignTable['u60'] = 'center';gv_vAlignTable['u34'] = 'center';gv_vAlignTable['u17'] = 'top';gv_vAlignTable['u64'] = 'center';gv_vAlignTable['u19'] = 'center';gv_vAlignTable['u11'] = 'center';gv_vAlignTable['u71'] = 'top';gv_vAlignTable['u15'] = 'top';gv_vAlignTable['u36'] = 'top';gv_vAlignTable['u75'] = 'top';gv_vAlignTable['u58'] = 'center';document.getElementById('u2_img').tabIndex = 0;

u2.style.cursor = 'pointer';
$axure.eventManager.click('u2', function(e) {

if (true) {

	SetPanelVisibility('u7','','none',500);

}
});
gv_vAlignTable['u13'] = 'center';gv_vAlignTable['u52'] = 'center';gv_vAlignTable['u3'] = 'center';gv_vAlignTable['u68'] = 'center';gv_vAlignTable['u73'] = 'center';gv_vAlignTable['u50'] = 'center';gv_vAlignTable['u28'] = 'center';gv_vAlignTable['u54'] = 'center';u6.tabIndex = 0;

u6.style.cursor = 'pointer';
$axure.eventManager.click('u6', function(e) {

if (true) {

	SetPanelVisibility('u7','','none',500);

}
});
gv_vAlignTable['u6'] = 'top';gv_vAlignTable['u61'] = 'top';gv_vAlignTable['u35'] = 'top';gv_vAlignTable['u26'] = 'top';gv_vAlignTable['u56'] = 'center';gv_vAlignTable['u5'] = 'center';gv_vAlignTable['u9'] = 'center';gv_vAlignTable['u42'] = 'center';document.getElementById('u72_img').tabIndex = 0;

u72.style.cursor = 'pointer';
$axure.eventManager.click('u72', function(e) {

if (true) {

	SetPanelVisibility('u7','hidden','none',500);

}
});
gv_vAlignTable['u48'] = 'center';gv_vAlignTable['u40'] = 'center';gv_vAlignTable['u70'] = 'center';gv_vAlignTable['u14'] = 'top';gv_vAlignTable['u44'] = 'center';gv_vAlignTable['u74'] = 'top';