﻿var sitemap = 

(function() {
    var _ = function() { var r={},a=arguments; for(var i=0; i<a.length; i+=2) r[a[i]]=a[i+1]; return r; }
    var _creator = function() { return _(b,[_(c,d,e,f,g,h,i,[_(c,j,e,f,g,k),_(c,l,e,f,g,m),_(c,n,e,f,g,o),_(c,p,e,f,g,q),_(c,r,e,f,g,s),_(c,t,e,f,g,u)]),_(c,v,e,f,g,w,i,[_(c,x,e,f,g,y)])]);}; 
var b="rootNodes",c="pageName",d="Home",e="type",f="Wireframe",g="url",h="Home.html",i="children",j="已有預約訂課",k="已有預約訂課.html",l="進入時的時段未預約",m="進入時的時段未預約.html",n="尚未預約訂課",o="尚未預約訂課.html",p="可預約畫面",q="可預約畫面.html",r="選擇主題",s="選擇主題.html",t="進入諮詢室",u="進入諮詢室.html",v="選擇主題_效果",w="選擇主題_效果.html",x="選擇主題_效果2",y="選擇主題_效果2.html";
return _creator();
})();
