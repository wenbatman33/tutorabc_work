for(var i = 0; i < 91; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u21'] = 'top';gv_vAlignTable['u86'] = 'top';gv_vAlignTable['u51'] = 'center';gv_vAlignTable['u16'] = 'center';gv_vAlignTable['u55'] = 'top';gv_vAlignTable['u76'] = 'center';document.getElementById('u31_img').tabIndex = 0;

u31.style.cursor = 'pointer';
$axure.eventManager.click('u31', function(e) {

if (true) {

}
});

$axure.eventManager.mouseover('u31', function(e) {
if (!IsTrueMouseOver('u31',e)) return;
if (true) {

	SetPanelState('u35', 'pd0u35','none','',500,'swing','up',400);

	SetPanelVisibility('u4','hidden','none',500);

	SetPanelVisibility('u62','hidden','none',500);

}
});
gv_vAlignTable['u77'] = 'top';gv_vAlignTable['u32'] = 'center';gv_vAlignTable['u23'] = 'center';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u27'] = 'top';gv_vAlignTable['u66'] = 'center';gv_vAlignTable['u30'] = 'top';gv_vAlignTable['u8'] = 'center';gv_vAlignTable['u60'] = 'center';document.getElementById('u89_img').tabIndex = 0;

u89.style.cursor = 'pointer';
$axure.eventManager.click('u89', function(e) {

if (true) {

}
});

$axure.eventManager.mouseover('u89', function(e) {
if (!IsTrueMouseOver('u89',e)) return;
if (true) {

	SetPanelVisibility('u4','hidden','none',500);

	SetPanelVisibility('u35','hidden','none',500);

	SetPanelVisibility('u62','hidden','none',500);

}
});
gv_vAlignTable['u34'] = 'center';gv_vAlignTable['u17'] = 'top';gv_vAlignTable['u64'] = 'center';gv_vAlignTable['u49'] = 'top';gv_vAlignTable['u79'] = 'center';gv_vAlignTable['u85'] = 'center';gv_vAlignTable['u11'] = 'top';gv_vAlignTable['u41'] = 'center';gv_vAlignTable['u45'] = 'top';gv_vAlignTable['u58'] = 'top';gv_vAlignTable['u37'] = 'center';document.getElementById('u2_img').tabIndex = 0;

u2.style.cursor = 'pointer';
$axure.eventManager.click('u2', function(e) {

if (true) {

}
});

$axure.eventManager.mouseover('u2', function(e) {
if (!IsTrueMouseOver('u2',e)) return;
if (true) {

	SetPanelState('u4', 'pd0u4','none','',500,'swing','up',400);

	SetPanelVisibility('u35','hidden','none',500);

	SetPanelVisibility('u62','hidden','none',500);

}
});
gv_vAlignTable['u83'] = 'top';gv_vAlignTable['u13'] = 'center';gv_vAlignTable['u52'] = 'top';gv_vAlignTable['u3'] = 'center';gv_vAlignTable['u47'] = 'center';gv_vAlignTable['u90'] = 'center';gv_vAlignTable['u73'] = 'top';gv_vAlignTable['u20'] = 'center';gv_vAlignTable['u24'] = 'top';gv_vAlignTable['u54'] = 'center';gv_vAlignTable['u39'] = 'center';gv_vAlignTable['u69'] = 'center';gv_vAlignTable['u6'] = 'center';gv_vAlignTable['u61'] = 'top';gv_vAlignTable['u26'] = 'center';gv_vAlignTable['u82'] = 'center';gv_vAlignTable['u42'] = 'top';document.getElementById('u33_img').tabIndex = 0;

u33.style.cursor = 'pointer';
$axure.eventManager.click('u33', function(e) {

if (true) {

}
});

$axure.eventManager.mouseover('u33', function(e) {
if (!IsTrueMouseOver('u33',e)) return;
if (true) {

	SetPanelState('u62', 'pd0u62','none','',500,'swing','up',400);

	SetPanelVisibility('u4','hidden','none',500);

	SetPanelVisibility('u35','hidden','none',500);

}
});
gv_vAlignTable['u72'] = 'center';gv_vAlignTable['u18'] = 'top';gv_vAlignTable['u48'] = 'top';gv_vAlignTable['u67'] = 'top';gv_vAlignTable['u88'] = 'center';gv_vAlignTable['u57'] = 'center';gv_vAlignTable['u10'] = 'center';gv_vAlignTable['u70'] = 'top';gv_vAlignTable['u14'] = 'top';gv_vAlignTable['u44'] = 'center';gv_vAlignTable['u74'] = 'top';gv_vAlignTable['u29'] = 'center';gv_vAlignTable['u80'] = 'top';