for(var i = 0; i < 86; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u21'] = 'center';gv_vAlignTable['u51'] = 'center';gv_vAlignTable['u25'] = 'center';gv_vAlignTable['u55'] = 'center';gv_vAlignTable['u6'] = 'center';gv_vAlignTable['u77'] = 'center';gv_vAlignTable['u23'] = 'center';gv_vAlignTable['u53'] = 'center';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u4'] = 'center';gv_vAlignTable['u30'] = 'center';gv_vAlignTable['u8'] = 'center';gv_vAlignTable['u17'] = 'center';gv_vAlignTable['u19'] = 'center';gv_vAlignTable['u49'] = 'center';gv_vAlignTable['u79'] = 'center';gv_vAlignTable['u81'] = 'center';gv_vAlignTable['u85'] = 'center';gv_vAlignTable['u41'] = 'center';gv_vAlignTable['u71'] = 'center';gv_vAlignTable['u15'] = 'center';gv_vAlignTable['u45'] = 'center';gv_vAlignTable['u75'] = 'center';gv_vAlignTable['u37'] = 'center';gv_vAlignTable['u2'] = 'top';gv_vAlignTable['u83'] = 'center';gv_vAlignTable['u13'] = 'top';gv_vAlignTable['u43'] = 'center';document.getElementById('u0_img').tabIndex = 0;

u0.style.cursor = 'pointer';
$axure.eventManager.click('u0', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('VIPABC.html');

}
});
gv_vAlignTable['u47'] = 'center';gv_vAlignTable['u73'] = 'center';document.getElementById('u84_img').tabIndex = 0;

u84.style.cursor = 'pointer';
$axure.eventManager.click('u84', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Step2選擇主題.html');

}
});
gv_vAlignTable['u28'] = 'center';gv_vAlignTable['u39'] = 'center';gv_vAlignTable['u69'] = 'center';gv_vAlignTable['u61'] = 'center';gv_vAlignTable['u35'] = 'center';u26.tabIndex = 0;

u26.style.cursor = 'pointer';
$axure.eventManager.click('u26', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('VIPABC.html');

}
});
gv_vAlignTable['u26'] = 'top';gv_vAlignTable['u65'] = 'center';gv_vAlignTable['u12'] = 'center';gv_vAlignTable['u33'] = 'center';gv_vAlignTable['u63'] = 'center';gv_vAlignTable['u67'] = 'center';gv_vAlignTable['u57'] = 'center';gv_vAlignTable['u10'] = 'center';gv_vAlignTable['u59'] = 'center';document.getElementById('u80_img').tabIndex = 0;

u80.style.cursor = 'pointer';
$axure.eventManager.click('u80', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Step2選擇主題.html');

}
});
