for(var i = 0; i < 51; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u17'] = 'center';gv_vAlignTable['u28'] = 'center';gv_vAlignTable['u8'] = 'center';gv_vAlignTable['u30'] = 'center';gv_vAlignTable['u21'] = 'center';gv_vAlignTable['u6'] = 'center';gv_vAlignTable['u13'] = 'top';gv_vAlignTable['u15'] = 'center';gv_vAlignTable['u43'] = 'center';gv_vAlignTable['u1'] = 'center';u26.tabIndex = 0;

u26.style.cursor = 'pointer';
$axure.eventManager.click('u26', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('VIPABC.html');

}
});
gv_vAlignTable['u26'] = 'top';gv_vAlignTable['u37'] = 'center';gv_vAlignTable['u41'] = 'center';gv_vAlignTable['u10'] = 'center';gv_vAlignTable['u12'] = 'center';gv_vAlignTable['u39'] = 'center';gv_vAlignTable['u35'] = 'center';gv_vAlignTable['u23'] = 'center';gv_vAlignTable['u4'] = 'center';gv_vAlignTable['u46'] = 'top';gv_vAlignTable['u2'] = 'top';gv_vAlignTable['u19'] = 'center';gv_vAlignTable['u48'] = 'center';gv_vAlignTable['u50'] = 'center';gv_vAlignTable['u25'] = 'center';gv_vAlignTable['u45'] = 'center';gv_vAlignTable['u33'] = 'center';document.getElementById('u0_img').tabIndex = 0;

u0.style.cursor = 'pointer';
$axure.eventManager.click('u0', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('VIPABC.html');

}
});
