for(var i = 0; i < 69; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u21'] = 'center';gv_vAlignTable['u51'] = 'center';gv_vAlignTable['u25'] = 'center';gv_vAlignTable['u6'] = 'center';gv_vAlignTable['u23'] = 'center';gv_vAlignTable['u53'] = 'center';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u4'] = 'center';gv_vAlignTable['u66'] = 'center';gv_vAlignTable['u30'] = 'center';gv_vAlignTable['u8'] = 'center';document.getElementById('u60_img').tabIndex = 0;

u60.style.cursor = 'pointer';
$axure.eventManager.click('u60', function(e) {

if (true) {

	SetPanelVisibility('u55','hidden','fade',500);

}
});
gv_vAlignTable['u17'] = 'center';gv_vAlignTable['u64'] = 'center';gv_vAlignTable['u19'] = 'center';gv_vAlignTable['u49'] = 'center';gv_vAlignTable['u41'] = 'center';gv_vAlignTable['u15'] = 'center';gv_vAlignTable['u45'] = 'center';gv_vAlignTable['u37'] = 'center';gv_vAlignTable['u2'] = 'top';gv_vAlignTable['u13'] = 'top';document.getElementById('u52_img').tabIndex = 0;

u52.style.cursor = 'pointer';
$axure.eventManager.click('u52', u52Click);
InsertAfterBegin(document.body, "<div class='intcases' id='u52LinksClick'></div>")
var u52LinksClick = document.getElementById('u52LinksClick');
function u52Click(e) 
{
windowEvent = e;


	ToggleLinks(e, 'u52LinksClick');
}

InsertBeforeEnd(u52LinksClick, "<div class='intcaselink' onmouseout='SuppressBubble(event)' onclick='u52Clicku0d6ca3070db442c1bd6e02b3e15b9282(event)'>課程未開始</div>");
function u52Clicku0d6ca3070db442c1bd6e02b3e15b9282(e)
{

	ToggleLinks(e, 'u52LinksClick');
}

InsertBeforeEnd(u52LinksClick, "<div class='intcaselink' onmouseout='SuppressBubble(event)' onclick='u52Clickuc3cf0ba8986c48a2a62d0ce6d71c5cf3(event)'>課程已開始</div>");
function u52Clickuc3cf0ba8986c48a2a62d0ce6d71c5cf3(e)
{

	self.location.href=$axure.globalVariableProvider.getLinkUrl('學堂預備室_上課中.html');

	ToggleLinks(e, 'u52LinksClick');
}
gv_vAlignTable['u43'] = 'center';document.getElementById('u0_img').tabIndex = 0;

u0.style.cursor = 'pointer';
$axure.eventManager.click('u0', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('VIPABC.html');

}
});
gv_vAlignTable['u47'] = 'center';gv_vAlignTable['u68'] = 'center';document.getElementById('u50_img').tabIndex = 0;

u50.style.cursor = 'pointer';
$axure.eventManager.click('u50', function(e) {

if (true) {

	SetPanelVisibility('u55','','fade',500);

}
});
gv_vAlignTable['u28'] = 'center';gv_vAlignTable['u54'] = 'top';gv_vAlignTable['u39'] = 'center';gv_vAlignTable['u61'] = 'center';gv_vAlignTable['u35'] = 'center';u26.tabIndex = 0;

u26.style.cursor = 'pointer';
$axure.eventManager.click('u26', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('VIPABC.html');

}
});
gv_vAlignTable['u26'] = 'top';document.getElementById('u65_img').tabIndex = 0;

u65.style.cursor = 'pointer';
$axure.eventManager.click('u65', function(e) {

if (true) {

	SetPanelVisibility('u62','hidden','fade',500);

}
});
gv_vAlignTable['u12'] = 'center';gv_vAlignTable['u33'] = 'center';document.getElementById('u63_img').tabIndex = 0;

u63.style.cursor = 'pointer';
$axure.eventManager.click('u63', function(e) {

if (true) {

	SetPanelVisibility('u62','hidden','fade',500);

}
});
document.getElementById('u48_img').tabIndex = 0;

u48.style.cursor = 'pointer';
$axure.eventManager.click('u48', function(e) {

if (true) {

}
});
document.getElementById('u67_img').tabIndex = 0;

u67.style.cursor = 'pointer';
$axure.eventManager.click('u67', function(e) {

if (true) {

	SetPanelVisibility('u62','hidden','fade',500);

}
});
gv_vAlignTable['u57'] = 'center';gv_vAlignTable['u10'] = 'center';gv_vAlignTable['u59'] = 'center';