for(var i = 0; i < 107; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u21'] = 'center';gv_vAlignTable['u86'] = 'center';gv_vAlignTable['u51'] = 'center';gv_vAlignTable['u25'] = 'center';gv_vAlignTable['u55'] = 'center';document.getElementById('u46_img').tabIndex = 0;
HookHover('u46', false);

u46.style.cursor = 'pointer';
$axure.eventManager.click('u46', function(e) {

if (true) {

}
});
gv_vAlignTable['u76'] = 'center';gv_vAlignTable['u6'] = 'center';gv_vAlignTable['u102'] = 'top';document.getElementById('u77_img').tabIndex = 0;
HookHover('u77', false);

u77.style.cursor = 'pointer';
$axure.eventManager.click('u77', function(e) {

if (true) {

}
});
gv_vAlignTable['u93'] = 'center';gv_vAlignTable['u23'] = 'center';gv_vAlignTable['u53'] = 'center';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u4'] = 'center';gv_vAlignTable['u66'] = 'center';gv_vAlignTable['u104'] = 'center';gv_vAlignTable['u30'] = 'center';gv_vAlignTable['u8'] = 'center';document.getElementById('u60_img').tabIndex = 0;

u60.style.cursor = 'pointer';
$axure.eventManager.click('u60', function(e) {

if (true) {

	SetPanelVisibility('u87','','fade',500);

}
});
gv_vAlignTable['u89'] = 'center';gv_vAlignTable['u17'] = 'center';gv_vAlignTable['u100'] = 'top';gv_vAlignTable['u19'] = 'center';gv_vAlignTable['u49'] = 'center';document.getElementById('u79_img').tabIndex = 0;
HookHover('u79', false);

u79.style.cursor = 'pointer';
$axure.eventManager.click('u79', function(e) {

if (true) {

}
});
document.getElementById('u81_img').tabIndex = 0;
HookHover('u81', false);

u81.style.cursor = 'pointer';
$axure.eventManager.click('u81', function(e) {

if (true) {

}
});
gv_vAlignTable['u97'] = 'center';gv_vAlignTable['u41'] = 'center';document.getElementById('u71_img').tabIndex = 0;
HookHover('u71', false);

u71.style.cursor = 'pointer';
$axure.eventManager.click('u71', function(e) {

if (true) {

}
});
gv_vAlignTable['u15'] = 'center';gv_vAlignTable['u45'] = 'center';document.getElementById('u75_img').tabIndex = 0;
HookHover('u75', false);

u75.style.cursor = 'pointer';
$axure.eventManager.click('u75', function(e) {

if (true) {

}
});
gv_vAlignTable['u37'] = 'center';gv_vAlignTable['u2'] = 'top';document.getElementById('u83_img').tabIndex = 0;

u83.style.cursor = 'pointer';
$axure.eventManager.click('u83', function(e) {

if (true) {

	SetPanelVisibility('u64','hidden','none',500);

}
});
gv_vAlignTable['u95'] = 'center';gv_vAlignTable['u13'] = 'top';document.getElementById('u52_img').tabIndex = 0;
HookHover('u52', false);

u52.style.cursor = 'pointer';
$axure.eventManager.click('u52', function(e) {

if (true) {

}
});
gv_vAlignTable['u43'] = 'center';document.getElementById('u0_img').tabIndex = 0;

u0.style.cursor = 'pointer';
$axure.eventManager.click('u0', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('VIPABC.html');

}
});
gv_vAlignTable['u47'] = 'center';gv_vAlignTable['u68'] = 'center';document.getElementById('u73_img').tabIndex = 0;
HookHover('u73', false);

u73.style.cursor = 'pointer';
$axure.eventManager.click('u73', function(e) {

if (true) {

}
});
gv_vAlignTable['u84'] = 'center';document.getElementById('u50_img').tabIndex = 0;
HookHover('u50', false);

u50.style.cursor = 'pointer';
$axure.eventManager.click('u50', function(e) {

if (true) {

}
});

u106.style.cursor = 'pointer';
$axure.eventManager.click('u106', function(e) {

if (true) {

	SetPanelVisibility('u87','hidden','none',500);

}
});
gv_vAlignTable['u28'] = 'center';document.getElementById('u54_img').tabIndex = 0;
HookHover('u54', false);

u54.style.cursor = 'pointer';
$axure.eventManager.click('u54', function(e) {

if (true) {

}
});
gv_vAlignTable['u99'] = 'center';gv_vAlignTable['u39'] = 'center';document.getElementById('u69_img').tabIndex = 0;
HookHover('u69', false);

u69.style.cursor = 'pointer';
$axure.eventManager.click('u69', function(e) {

if (true) {

}
});
gv_vAlignTable['u78'] = 'center';gv_vAlignTable['u61'] = 'center';gv_vAlignTable['u91'] = 'center';gv_vAlignTable['u35'] = 'center';u26.tabIndex = 0;

u26.style.cursor = 'pointer';
$axure.eventManager.click('u26', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('VIPABC.html');

}
});
gv_vAlignTable['u26'] = 'top';document.getElementById('u56_img').tabIndex = 0;

u56.style.cursor = 'pointer';
$axure.eventManager.click('u56', function(e) {

if (true) {

	SetPanelVisibility('u64','','none',500);

}
});

u105.style.cursor = 'pointer';
$axure.eventManager.click('u105', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Step3學堂預備室_上課前.html');

}
});
gv_vAlignTable['u82'] = 'center';gv_vAlignTable['u12'] = 'center';document.getElementById('u42_img').tabIndex = 0;
HookHover('u42', false);

u42.style.cursor = 'pointer';
$axure.eventManager.click('u42', function(e) {

if (true) {

}
});
gv_vAlignTable['u33'] = 'center';gv_vAlignTable['u72'] = 'center';gv_vAlignTable['u63'] = 'center';document.getElementById('u48_img').tabIndex = 0;
HookHover('u48', false);

u48.style.cursor = 'pointer';
$axure.eventManager.click('u48', function(e) {

if (true) {

}
});
document.getElementById('u67_img').tabIndex = 0;
HookHover('u67', false);

u67.style.cursor = 'pointer';
$axure.eventManager.click('u67', function(e) {

if (true) {

}
});
gv_vAlignTable['u57'] = 'center';gv_vAlignTable['u101'] = 'top';gv_vAlignTable['u10'] = 'center';document.getElementById('u40_img').tabIndex = 0;
HookHover('u40', false);

u40.style.cursor = 'pointer';
$axure.eventManager.click('u40', function(e) {

if (true) {

}
});
gv_vAlignTable['u70'] = 'center';document.getElementById('u44_img').tabIndex = 0;
HookHover('u44', false);

u44.style.cursor = 'pointer';
$axure.eventManager.click('u44', function(e) {

if (true) {

}
});
gv_vAlignTable['u74'] = 'center';gv_vAlignTable['u59'] = 'center';gv_vAlignTable['u80'] = 'center';