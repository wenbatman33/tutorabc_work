$(function() {
	$(".btn_Language").click(function() {
		$(".dropdown-menu").toggle();
	});
});	