for(var i = 0; i < 125; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u86'] = 'top';gv_vAlignTable['u102'] = 'top';gv_vAlignTable['u25'] = 'top';gv_vAlignTable['u16'] = 'top';gv_vAlignTable['u46'] = 'center';u76.tabIndex = 0;

u76.style.cursor = 'pointer';
$axure.eventManager.click('u76', function(e) {

if (true) {

    self.location.href="resources/reload.html#" + encodeURI($axure.globalVariableProvider.getLinkUrl($axure.pageData.url));

}
});
gv_vAlignTable['u93'] = 'top';gv_vAlignTable['u38'] = 'top';gv_vAlignTable['u32'] = 'center';gv_vAlignTable['u23'] = 'top';gv_vAlignTable['u62'] = 'center';gv_vAlignTable['u7'] = 'center';gv_vAlignTable['u66'] = 'center';gv_vAlignTable['u112'] = 'top';gv_vAlignTable['u115'] = 'top';gv_vAlignTable['u30'] = 'top';gv_vAlignTable['u60'] = 'center';gv_vAlignTable['u34'] = 'top';gv_vAlignTable['u17'] = 'top';gv_vAlignTable['u64'] = 'top';u19.tabIndex = 0;

u19.style.cursor = 'pointer';
$axure.eventManager.click('u19', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('2、影片列表頁_九宮格_.html');

}
});
gv_vAlignTable['u103'] = 'top';gv_vAlignTable['u79'] = 'top';gv_vAlignTable['u81'] = 'center';gv_vAlignTable['u118'] = 'top';gv_vAlignTable['u124'] = 'top';gv_vAlignTable['u85'] = 'top';gv_vAlignTable['u108'] = 'center';gv_vAlignTable['u15'] = 'top';gv_vAlignTable['u36'] = 'top';u75.tabIndex = 0;

u75.style.cursor = 'pointer';
$axure.eventManager.click('u75', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('2、影片列表頁_九宮格_.html');

}
});
gv_vAlignTable['u58'] = 'center';gv_vAlignTable['u37'] = 'top';gv_vAlignTable['u92'] = 'center';gv_vAlignTable['u95'] = 'center';gv_vAlignTable['u22'] = 'top';gv_vAlignTable['u52'] = 'center';gv_vAlignTable['u43'] = 'top';gv_vAlignTable['u0'] = 'top';gv_vAlignTable['u3'] = 'center';gv_vAlignTable['u68'] = 'center';gv_vAlignTable['u84'] = 'center';u20.tabIndex = 0;

u20.style.cursor = 'pointer';
$axure.eventManager.click('u20', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('3、問答頁.html');

}
});
gv_vAlignTable['u50'] = 'center';gv_vAlignTable['u106'] = 'top';gv_vAlignTable['u24'] = 'top';gv_vAlignTable['u54'] = 'center';gv_vAlignTable['u99'] = 'top';gv_vAlignTable['u113'] = 'top';gv_vAlignTable['u111'] = 'center';gv_vAlignTable['u78'] = 'center';gv_vAlignTable['u120'] = 'center';gv_vAlignTable['u114'] = 'top';gv_vAlignTable['u96'] = 'top';gv_vAlignTable['u35'] = 'top';gv_vAlignTable['u56'] = 'center';gv_vAlignTable['u105'] = 'center';gv_vAlignTable['u109'] = 'top';gv_vAlignTable['u123'] = 'center';gv_vAlignTable['u82'] = 'top';gv_vAlignTable['u5'] = 'center';gv_vAlignTable['u12'] = 'center';gv_vAlignTable['u9'] = 'center';gv_vAlignTable['u33'] = 'top';gv_vAlignTable['u72'] = 'center';gv_vAlignTable['u63'] = 'top';u18.tabIndex = 0;

u18.style.cursor = 'pointer';
$axure.eventManager.click('u18', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('1、影片首頁.html');

}
});
gv_vAlignTable['u48'] = 'center';gv_vAlignTable['u88'] = 'center';gv_vAlignTable['u101'] = 'center';gv_vAlignTable['u10'] = 'top';gv_vAlignTable['u70'] = 'center';gv_vAlignTable['u44'] = 'top';gv_vAlignTable['u117'] = 'center';gv_vAlignTable['u74'] = 'center';gv_vAlignTable['u29'] = 'center';gv_vAlignTable['u98'] = 'center';gv_vAlignTable['u121'] = 'top';