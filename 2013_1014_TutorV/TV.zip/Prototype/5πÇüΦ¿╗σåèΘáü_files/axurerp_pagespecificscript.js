for(var i = 0; i < 78; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u21'] = 'top';gv_vAlignTable['u51'] = 'center';gv_vAlignTable['u16'] = 'center';document.getElementById('u31_img').tabIndex = 0;

u31.style.cursor = 'pointer';
$axure.eventManager.click('u31', function(e) {

if (true) {

	self.location.href='#';

}
});
gv_vAlignTable['u77'] = 'top';gv_vAlignTable['u38'] = 'top';gv_vAlignTable['u32'] = 'center';u23.tabIndex = 0;

u23.style.cursor = 'pointer';
$axure.eventManager.click('u23', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('2、影片列表頁_九宮格_.html');

}
});
gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u4'] = 'top';gv_vAlignTable['u7'] = 'center';gv_vAlignTable['u66'] = 'center';gv_vAlignTable['u34'] = 'top';gv_vAlignTable['u64'] = 'top';gv_vAlignTable['u19'] = 'top';gv_vAlignTable['u49'] = 'center';gv_vAlignTable['u11'] = 'center';gv_vAlignTable['u41'] = 'center';gv_vAlignTable['u45'] = 'center';gv_vAlignTable['u36'] = 'top';gv_vAlignTable['u75'] = 'center';gv_vAlignTable['u58'] = 'center';gv_vAlignTable['u37'] = 'top';u22.tabIndex = 0;

u22.style.cursor = 'pointer';
$axure.eventManager.click('u22', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('1、影片首頁.html');

}
});
gv_vAlignTable['u13'] = 'center';gv_vAlignTable['u52'] = 'top';gv_vAlignTable['u43'] = 'center';gv_vAlignTable['u3'] = 'center';gv_vAlignTable['u27'] = 'top';gv_vAlignTable['u47'] = 'center';gv_vAlignTable['u68'] = 'center';gv_vAlignTable['u73'] = 'top';gv_vAlignTable['u20'] = 'top';gv_vAlignTable['u28'] = 'top';u24.tabIndex = 0;

u24.style.cursor = 'pointer';
$axure.eventManager.click('u24', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('3、問答頁.html');

}
});
gv_vAlignTable['u54'] = 'center';gv_vAlignTable['u39'] = 'top';gv_vAlignTable['u61'] = 'center';gv_vAlignTable['u35'] = 'top';gv_vAlignTable['u26'] = 'top';gv_vAlignTable['u56'] = 'center';gv_vAlignTable['u9'] = 'center';gv_vAlignTable['u72'] = 'center';gv_vAlignTable['u63'] = 'center';gv_vAlignTable['u70'] = 'center';gv_vAlignTable['u14'] = 'top';gv_vAlignTable['u29'] = 'top';gv_vAlignTable['u59'] = 'top';