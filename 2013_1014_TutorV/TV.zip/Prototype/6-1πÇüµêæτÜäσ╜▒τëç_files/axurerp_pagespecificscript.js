for(var i = 0; i < 109; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u21'] = 'center';gv_vAlignTable['u86'] = 'top';gv_vAlignTable['u51'] = 'center';gv_vAlignTable['u25'] = 'top';u16.tabIndex = 0;

u16.style.cursor = 'pointer';
$axure.eventManager.click('u16', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('3、問答頁.html');

}
});
gv_vAlignTable['u55'] = 'top';gv_vAlignTable['u46'] = 'top';gv_vAlignTable['u76'] = 'top';gv_vAlignTable['u38'] = 'center';gv_vAlignTable['u32'] = 'center';gv_vAlignTable['u23'] = 'center';gv_vAlignTable['u62'] = 'top';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u27'] = 'center';gv_vAlignTable['u66'] = 'center';gv_vAlignTable['u104'] = 'top';gv_vAlignTable['u30'] = 'top';gv_vAlignTable['u8'] = 'center';gv_vAlignTable['u60'] = 'center';gv_vAlignTable['u89'] = 'top';gv_vAlignTable['u34'] = 'top';gv_vAlignTable['u64'] = 'center';document.getElementById('u100_img').tabIndex = 0;

u100.style.cursor = 'pointer';
$axure.eventManager.click('u100', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('6-3、我的詞庫.html');

}
});
gv_vAlignTable['u19'] = 'center';gv_vAlignTable['u49'] = 'center';gv_vAlignTable['u103'] = 'center';gv_vAlignTable['u81'] = 'top';gv_vAlignTable['u97'] = 'center';gv_vAlignTable['u11'] = 'top';gv_vAlignTable['u41'] = 'center';gv_vAlignTable['u108'] = 'center';u15.tabIndex = 0;

u15.style.cursor = 'pointer';
$axure.eventManager.click('u15', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('2、影片列表頁_九宮格_.html');

}
});
gv_vAlignTable['u45'] = 'center';gv_vAlignTable['u36'] = 'center';gv_vAlignTable['u75'] = 'top';gv_vAlignTable['u58'] = 'top';gv_vAlignTable['u2'] = 'top';gv_vAlignTable['u92'] = 'center';gv_vAlignTable['u83'] = 'center';gv_vAlignTable['u95'] = 'top';document.getElementById('u22_img').tabIndex = 0;

u22.style.cursor = 'pointer';
$axure.eventManager.click('u22', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('6-2、我的問答.html');

}
});
gv_vAlignTable['u13'] = 'top';gv_vAlignTable['u52'] = 'top';gv_vAlignTable['u43'] = 'top';gv_vAlignTable['u47'] = 'top';gv_vAlignTable['u90'] = 'top';gv_vAlignTable['u84'] = 'top';document.getElementById('u20_img').tabIndex = 0;

u20.style.cursor = 'pointer';
$axure.eventManager.click('u20', function(e) {

if (true) {

    self.location.href="resources/reload.html#" + encodeURI($axure.globalVariableProvider.getLinkUrl($axure.pageData.url));

}
});
gv_vAlignTable['u54'] = 'center';gv_vAlignTable['u39'] = 'top';gv_vAlignTable['u69'] = 'center';gv_vAlignTable['u78'] = 'center';gv_vAlignTable['u94'] = 'center';gv_vAlignTable['u6'] = 'top';gv_vAlignTable['u61'] = 'top';document.getElementById('u26_img').tabIndex = 0;

u26.style.cursor = 'pointer';
$axure.eventManager.click('u26', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('6、會員中心.html');

}
});
gv_vAlignTable['u105'] = 'top';gv_vAlignTable['u5'] = 'center';gv_vAlignTable['u12'] = 'top';gv_vAlignTable['u42'] = 'top';gv_vAlignTable['u33'] = 'top';gv_vAlignTable['u72'] = 'top';gv_vAlignTable['u67'] = 'top';gv_vAlignTable['u88'] = 'center';gv_vAlignTable['u101'] = 'center';gv_vAlignTable['u70'] = 'top';u14.tabIndex = 0;

u14.style.cursor = 'pointer';
$axure.eventManager.click('u14', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('1、影片首頁.html');

}
});
gv_vAlignTable['u74'] = 'center';gv_vAlignTable['u29'] = 'center';gv_vAlignTable['u98'] = 'top';gv_vAlignTable['u80'] = 'center';