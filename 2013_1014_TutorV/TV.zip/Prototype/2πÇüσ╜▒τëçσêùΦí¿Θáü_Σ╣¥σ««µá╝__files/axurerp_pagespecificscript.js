for(var i = 0; i < 179; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u122'] = 'center';gv_vAlignTable['u32'] = 'center';gv_vAlignTable['u156'] = 'top';gv_vAlignTable['u7'] = 'center';gv_vAlignTable['u153'] = 'top';gv_vAlignTable['u140'] = 'center';gv_vAlignTable['u17'] = 'top';gv_vAlignTable['u135'] = 'top';gv_vAlignTable['u42'] = 'center';gv_vAlignTable['u159'] = 'top';gv_vAlignTable['u48'] = 'center';gv_vAlignTable['u105'] = 'top';gv_vAlignTable['u27'] = 'top';gv_vAlignTable['u138'] = 'top';gv_vAlignTable['u52'] = 'center';u20.tabIndex = 0;

u20.style.cursor = 'pointer';
$axure.eventManager.click('u20', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('3、問答頁.html');

}
});
gv_vAlignTable['u120'] = 'top';gv_vAlignTable['u152'] = 'center';gv_vAlignTable['u110'] = 'center';gv_vAlignTable['u108'] = 'top';gv_vAlignTable['u141'] = 'top';gv_vAlignTable['u34'] = 'center';gv_vAlignTable['u68'] = 'center';gv_vAlignTable['u72'] = 'center';gv_vAlignTable['u164'] = 'center';gv_vAlignTable['u66'] = 'center';gv_vAlignTable['u78'] = 'center';gv_vAlignTable['u57'] = 'top';gv_vAlignTable['u119'] = 'center';gv_vAlignTable['u16'] = 'top';gv_vAlignTable['u125'] = 'center';gv_vAlignTable['u149'] = 'center';u54.tabIndex = 0;

u54.style.cursor = 'pointer';
$axure.eventManager.click('u54', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('2-1、影片列表頁.html');

}
});
gv_vAlignTable['u88'] = 'center';gv_vAlignTable['u38'] = 'center';gv_vAlignTable['u176'] = 'center';gv_vAlignTable['u174'] = 'top';gv_vAlignTable['u128'] = 'center';gv_vAlignTable['u10'] = 'top';gv_vAlignTable['u100'] = 'center';gv_vAlignTable['u23'] = 'top';gv_vAlignTable['u144'] = 'top';gv_vAlignTable['u82'] = 'center';gv_vAlignTable['u36'] = 'center';gv_vAlignTable['u30'] = 'center';gv_vAlignTable['u61'] = 'top';gv_vAlignTable['u116'] = 'center';gv_vAlignTable['u158'] = 'center';gv_vAlignTable['u74'] = 'center';gv_vAlignTable['u123'] = 'top';gv_vAlignTable['u114'] = 'top';gv_vAlignTable['u92'] = 'center';gv_vAlignTable['u46'] = 'center';gv_vAlignTable['u126'] = 'top';gv_vAlignTable['u5'] = 'center';gv_vAlignTable['u98'] = 'center';gv_vAlignTable['u56'] = 'center';gv_vAlignTable['u150'] = 'top';gv_vAlignTable['u168'] = 'top';gv_vAlignTable['u40'] = 'center';u53.tabIndex = 0;

u53.style.cursor = 'pointer';
$axure.eventManager.click('u53', function(e) {

if (true) {

    self.location.href="resources/reload.html#" + encodeURI($axure.globalVariableProvider.getLinkUrl($axure.pageData.url));

}
});
gv_vAlignTable['u104'] = 'center';u19.tabIndex = 0;

u19.style.cursor = 'pointer';
$axure.eventManager.click('u19', function(e) {

if (true) {

    self.location.href="resources/reload.html#" + encodeURI($axure.globalVariableProvider.getLinkUrl($axure.pageData.url));

}
});
gv_vAlignTable['u155'] = 'center';gv_vAlignTable['u84'] = 'center';gv_vAlignTable['u50'] = 'center';gv_vAlignTable['u63'] = 'center';gv_vAlignTable['u170'] = 'center';gv_vAlignTable['u76'] = 'center';gv_vAlignTable['u134'] = 'center';gv_vAlignTable['u94'] = 'center';gv_vAlignTable['u60'] = 'center';gv_vAlignTable['u102'] = 'center';gv_vAlignTable['u9'] = 'center';gv_vAlignTable['u147'] = 'top';gv_vAlignTable['u131'] = 'center';gv_vAlignTable['u64'] = 'top';gv_vAlignTable['u70'] = 'center';gv_vAlignTable['u24'] = 'top';gv_vAlignTable['u162'] = 'top';gv_vAlignTable['u117'] = 'top';gv_vAlignTable['u113'] = 'center';gv_vAlignTable['u132'] = 'top';gv_vAlignTable['u129'] = 'top';gv_vAlignTable['u86'] = 'center';gv_vAlignTable['u58'] = 'top';gv_vAlignTable['u173'] = 'center';gv_vAlignTable['u111'] = 'top';gv_vAlignTable['u171'] = 'top';gv_vAlignTable['u0'] = 'top';gv_vAlignTable['u178'] = 'center';gv_vAlignTable['u3'] = 'center';gv_vAlignTable['u96'] = 'center';gv_vAlignTable['u146'] = 'center';gv_vAlignTable['u15'] = 'top';gv_vAlignTable['u80'] = 'center';gv_vAlignTable['u167'] = 'center';gv_vAlignTable['u12'] = 'center';gv_vAlignTable['u165'] = 'top';gv_vAlignTable['u25'] = 'top';gv_vAlignTable['u137'] = 'center';gv_vAlignTable['u90'] = 'center';u18.tabIndex = 0;

u18.style.cursor = 'pointer';
$axure.eventManager.click('u18', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('1、影片首頁.html');

}
});
gv_vAlignTable['u161'] = 'center';gv_vAlignTable['u22'] = 'top';gv_vAlignTable['u143'] = 'center';gv_vAlignTable['u107'] = 'center';