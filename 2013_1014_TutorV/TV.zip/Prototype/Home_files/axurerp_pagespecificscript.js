for(var i = 0; i < 58; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u31'] = 'center';
u16.style.cursor = 'pointer';
if (bIE) u16.attachEvent("onclick", ClickLinkToReferencePageu16);
else u16.addEventListener("click", ClickLinkToReferencePageu16, true);
function ClickLinkToReferencePageu16(e)
{
    self.location.href=$axure.globalVariableProvider.getLinkUrl('4、登入頁.html');
}

x = 0;
y = 56;
InsertAfterBegin(u16ann, "<img src='resources/images/newwindow.gif' id='u16PagePopup' style='cursor:pointer;position:absolute;z-index:500;left:" + x + ";top:" + y + "'>");

var u16PagePopup = document.getElementById('u16PagePopup');
if (bIE) u16PagePopup.attachEvent("onclick", u16PagePopupHandler);
else u16PagePopup.addEventListener("click", u16PagePopupHandler, true);

function u16PagePopupHandler(event)
{
    window.open($axure.globalVariableProvider.getLinkUrl('4、登入頁.html'));
}
gv_vAlignTable['u17'] = 'center';
u28.style.cursor = 'pointer';
if (bIE) u28.attachEvent("onclick", ClickLinkToReferencePageu28);
else u28.addEventListener("click", ClickLinkToReferencePageu28, true);
function ClickLinkToReferencePageu28(e)
{
    self.location.href=$axure.globalVariableProvider.getLinkUrl('6-3、我的詞庫.html');
}

x = 0;
y = 56;
InsertAfterBegin(u28ann, "<img src='resources/images/newwindow.gif' id='u28PagePopup' style='cursor:pointer;position:absolute;z-index:500;left:" + x + ";top:" + y + "'>");

var u28PagePopup = document.getElementById('u28PagePopup');
if (bIE) u28PagePopup.attachEvent("onclick", u28PagePopupHandler);
else u28PagePopup.addEventListener("click", u28PagePopupHandler, true);

function u28PagePopupHandler(event)
{
    window.open($axure.globalVariableProvider.getLinkUrl('6-3、我的詞庫.html'));
}
gv_vAlignTable['u29'] = 'center';
u8.style.cursor = 'pointer';
if (bIE) u8.attachEvent("onclick", ClickLinkToReferencePageu8);
else u8.addEventListener("click", ClickLinkToReferencePageu8, true);
function ClickLinkToReferencePageu8(e)
{
    self.location.href=$axure.globalVariableProvider.getLinkUrl('2-1、影片列表頁.html');
}

x = 0;
y = 56;
InsertAfterBegin(u8ann, "<img src='resources/images/newwindow.gif' id='u8PagePopup' style='cursor:pointer;position:absolute;z-index:500;left:" + x + ";top:" + y + "'>");

var u8PagePopup = document.getElementById('u8PagePopup');
if (bIE) u8PagePopup.attachEvent("onclick", u8PagePopupHandler);
else u8PagePopup.addEventListener("click", u8PagePopupHandler, true);

function u8PagePopupHandler(event)
{
    window.open($axure.globalVariableProvider.getLinkUrl('2-1、影片列表頁.html'));
}
gv_vAlignTable['u21'] = 'center';
u6.style.cursor = 'pointer';
if (bIE) u6.attachEvent("onclick", ClickLinkToReferencePageu6);
else u6.addEventListener("click", ClickLinkToReferencePageu6, true);
function ClickLinkToReferencePageu6(e)
{
    self.location.href=$axure.globalVariableProvider.getLinkUrl('2、影片列表頁_九宮格_.html');
}

x = 0;
y = 56;
InsertAfterBegin(u6ann, "<img src='resources/images/newwindow.gif' id='u6PagePopup' style='cursor:pointer;position:absolute;z-index:500;left:" + x + ";top:" + y + "'>");

var u6PagePopup = document.getElementById('u6PagePopup');
if (bIE) u6PagePopup.attachEvent("onclick", u6PagePopupHandler);
else u6PagePopup.addEventListener("click", u6PagePopupHandler, true);

function u6PagePopupHandler(event)
{
    window.open($axure.globalVariableProvider.getLinkUrl('2、影片列表頁_九宮格_.html'));
}
gv_vAlignTable['u57'] = 'center';gv_vAlignTable['u15'] = 'center';gv_vAlignTable['u13'] = 'center';
u14.style.cursor = 'pointer';
if (bIE) u14.attachEvent("onclick", ClickLinkToReferencePageu14);
else u14.addEventListener("click", ClickLinkToReferencePageu14, true);
function ClickLinkToReferencePageu14(e)
{
    self.location.href=$axure.globalVariableProvider.getLinkUrl('3-2、發問頁.html');
}

x = 0;
y = 56;
InsertAfterBegin(u14ann, "<img src='resources/images/newwindow.gif' id='u14PagePopup' style='cursor:pointer;position:absolute;z-index:500;left:" + x + ";top:" + y + "'>");

var u14PagePopup = document.getElementById('u14PagePopup');
if (bIE) u14PagePopup.attachEvent("onclick", u14PagePopupHandler);
else u14PagePopup.addEventListener("click", u14PagePopupHandler, true);

function u14PagePopupHandler(event)
{
    window.open($axure.globalVariableProvider.getLinkUrl('3-2、發問頁.html'));
}

u4.style.cursor = 'pointer';
if (bIE) u4.attachEvent("onclick", ClickLinkToReferencePageu4);
else u4.addEventListener("click", ClickLinkToReferencePageu4, true);
function ClickLinkToReferencePageu4(e)
{
    self.location.href=$axure.globalVariableProvider.getLinkUrl('1-2、影片內頁-手機驗證.html');
}

x = 0;
y = 56;
InsertAfterBegin(u4ann, "<img src='resources/images/newwindow.gif' id='u4PagePopup' style='cursor:pointer;position:absolute;z-index:500;left:" + x + ";top:" + y + "'>");

var u4PagePopup = document.getElementById('u4PagePopup');
if (bIE) u4PagePopup.attachEvent("onclick", u4PagePopupHandler);
else u4PagePopup.addEventListener("click", u4PagePopupHandler, true);

function u4PagePopupHandler(event)
{
    window.open($axure.globalVariableProvider.getLinkUrl('1-2、影片內頁-手機驗證.html'));
}
gv_vAlignTable['u43'] = 'center';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u37'] = 'center';
u26.style.cursor = 'pointer';
if (bIE) u26.attachEvent("onclick", ClickLinkToReferencePageu26);
else u26.addEventListener("click", ClickLinkToReferencePageu26, true);
function ClickLinkToReferencePageu26(e)
{
    self.location.href=$axure.globalVariableProvider.getLinkUrl('6-2、我的問答.html');
}

x = 0;
y = 56;
InsertAfterBegin(u26ann, "<img src='resources/images/newwindow.gif' id='u26PagePopup' style='cursor:pointer;position:absolute;z-index:500;left:" + x + ";top:" + y + "'>");

var u26PagePopup = document.getElementById('u26PagePopup');
if (bIE) u26PagePopup.attachEvent("onclick", u26PagePopupHandler);
else u26PagePopup.addEventListener("click", u26PagePopupHandler, true);

function u26PagePopupHandler(event)
{
    window.open($axure.globalVariableProvider.getLinkUrl('6-2、我的問答.html'));
}
gv_vAlignTable['u41'] = 'center';
u10.style.cursor = 'pointer';
if (bIE) u10.attachEvent("onclick", ClickLinkToReferencePageu10);
else u10.addEventListener("click", ClickLinkToReferencePageu10, true);
function ClickLinkToReferencePageu10(e)
{
    self.location.href=$axure.globalVariableProvider.getLinkUrl('3、問答頁.html');
}

x = 0;
y = 56;
InsertAfterBegin(u10ann, "<img src='resources/images/newwindow.gif' id='u10PagePopup' style='cursor:pointer;position:absolute;z-index:500;left:" + x + ";top:" + y + "'>");

var u10PagePopup = document.getElementById('u10PagePopup');
if (bIE) u10PagePopup.attachEvent("onclick", u10PagePopupHandler);
else u10PagePopup.addEventListener("click", u10PagePopupHandler, true);

function u10PagePopupHandler(event)
{
    window.open($axure.globalVariableProvider.getLinkUrl('3、問答頁.html'));
}
gv_vAlignTable['u11'] = 'center';gv_vAlignTable['u3'] = 'center';
u12.style.cursor = 'pointer';
if (bIE) u12.attachEvent("onclick", ClickLinkToReferencePageu12);
else u12.addEventListener("click", ClickLinkToReferencePageu12, true);
function ClickLinkToReferencePageu12(e)
{
    self.location.href=$axure.globalVariableProvider.getLinkUrl('3-1、問題內頁.html');
}

x = 0;
y = 56;
InsertAfterBegin(u12ann, "<img src='resources/images/newwindow.gif' id='u12PagePopup' style='cursor:pointer;position:absolute;z-index:500;left:" + x + ";top:" + y + "'>");

var u12PagePopup = document.getElementById('u12PagePopup');
if (bIE) u12PagePopup.attachEvent("onclick", u12PagePopupHandler);
else u12PagePopup.addEventListener("click", u12PagePopupHandler, true);

function u12PagePopupHandler(event)
{
    window.open($axure.globalVariableProvider.getLinkUrl('3-1、問題內頁.html'));
}
gv_vAlignTable['u39'] = 'center';gv_vAlignTable['u9'] = 'center';gv_vAlignTable['u35'] = 'center';gv_vAlignTable['u27'] = 'center';gv_vAlignTable['u7'] = 'center';gv_vAlignTable['u23'] = 'center';
u24.style.cursor = 'pointer';
if (bIE) u24.attachEvent("onclick", ClickLinkToReferencePageu24);
else u24.addEventListener("click", ClickLinkToReferencePageu24, true);
function ClickLinkToReferencePageu24(e)
{
    self.location.href=$axure.globalVariableProvider.getLinkUrl('6-1、我的影片.html');
}

x = 0;
y = 56;
InsertAfterBegin(u24ann, "<img src='resources/images/newwindow.gif' id='u24PagePopup' style='cursor:pointer;position:absolute;z-index:500;left:" + x + ";top:" + y + "'>");

var u24PagePopup = document.getElementById('u24PagePopup');
if (bIE) u24PagePopup.attachEvent("onclick", u24PagePopupHandler);
else u24PagePopup.addEventListener("click", u24PagePopupHandler, true);

function u24PagePopupHandler(event)
{
    window.open($axure.globalVariableProvider.getLinkUrl('6-1、我的影片.html'));
}
gv_vAlignTable['u25'] = 'center';gv_vAlignTable['u53'] = 'center';
u2.style.cursor = 'pointer';
if (bIE) u2.attachEvent("onclick", ClickLinkToReferencePageu2);
else u2.addEventListener("click", ClickLinkToReferencePageu2, true);
function ClickLinkToReferencePageu2(e)
{
    self.location.href=$axure.globalVariableProvider.getLinkUrl('1、影片首頁.html');
}

x = 0;
y = 56;
InsertAfterBegin(u2ann, "<img src='resources/images/newwindow.gif' id='u2PagePopup' style='cursor:pointer;position:absolute;z-index:500;left:" + x + ";top:" + y + "'>");

var u2PagePopup = document.getElementById('u2PagePopup');
if (bIE) u2PagePopup.attachEvent("onclick", u2PagePopupHandler);
else u2PagePopup.addEventListener("click", u2PagePopupHandler, true);

function u2PagePopupHandler(event)
{
    window.open($axure.globalVariableProvider.getLinkUrl('1、影片首頁.html'));
}

u18.style.cursor = 'pointer';
if (bIE) u18.attachEvent("onclick", ClickLinkToReferencePageu18);
else u18.addEventListener("click", ClickLinkToReferencePageu18, true);
function ClickLinkToReferencePageu18(e)
{
    self.location.href=$axure.globalVariableProvider.getLinkUrl('忘記密碼頁.html');
}

x = 0;
y = 56;
InsertAfterBegin(u18ann, "<img src='resources/images/newwindow.gif' id='u18PagePopup' style='cursor:pointer;position:absolute;z-index:500;left:" + x + ";top:" + y + "'>");

var u18PagePopup = document.getElementById('u18PagePopup');
if (bIE) u18PagePopup.attachEvent("onclick", u18PagePopupHandler);
else u18PagePopup.addEventListener("click", u18PagePopupHandler, true);

function u18PagePopupHandler(event)
{
    window.open($axure.globalVariableProvider.getLinkUrl('忘記密碼頁.html'));
}
gv_vAlignTable['u19'] = 'center';gv_vAlignTable['u55'] = 'center';
u20.style.cursor = 'pointer';
if (bIE) u20.attachEvent("onclick", ClickLinkToReferencePageu20);
else u20.addEventListener("click", ClickLinkToReferencePageu20, true);
function ClickLinkToReferencePageu20(e)
{
    self.location.href=$axure.globalVariableProvider.getLinkUrl('5、註冊頁.html');
}

x = 0;
y = 56;
InsertAfterBegin(u20ann, "<img src='resources/images/newwindow.gif' id='u20PagePopup' style='cursor:pointer;position:absolute;z-index:500;left:" + x + ";top:" + y + "'>");

var u20PagePopup = document.getElementById('u20PagePopup');
if (bIE) u20PagePopup.attachEvent("onclick", u20PagePopupHandler);
else u20PagePopup.addEventListener("click", u20PagePopupHandler, true);

function u20PagePopupHandler(event)
{
    window.open($axure.globalVariableProvider.getLinkUrl('5、註冊頁.html'));
}
gv_vAlignTable['u5'] = 'center';
u22.style.cursor = 'pointer';
if (bIE) u22.attachEvent("onclick", ClickLinkToReferencePageu22);
else u22.addEventListener("click", ClickLinkToReferencePageu22, true);
function ClickLinkToReferencePageu22(e)
{
    self.location.href=$axure.globalVariableProvider.getLinkUrl('6、會員中心.html');
}

x = 0;
y = 56;
InsertAfterBegin(u22ann, "<img src='resources/images/newwindow.gif' id='u22PagePopup' style='cursor:pointer;position:absolute;z-index:500;left:" + x + ";top:" + y + "'>");

var u22PagePopup = document.getElementById('u22PagePopup');
if (bIE) u22PagePopup.attachEvent("onclick", u22PagePopupHandler);
else u22PagePopup.addEventListener("click", u22PagePopupHandler, true);

function u22PagePopupHandler(event)
{
    window.open($axure.globalVariableProvider.getLinkUrl('6、會員中心.html'));
}
gv_vAlignTable['u49'] = 'center';gv_vAlignTable['u47'] = 'center';gv_vAlignTable['u51'] = 'center';gv_vAlignTable['u45'] = 'center';gv_vAlignTable['u33'] = 'center';
u0.style.cursor = 'pointer';
if (bIE) u0.attachEvent("onclick", ClickLinkToReferencePageu0);
else u0.addEventListener("click", ClickLinkToReferencePageu0, true);
function ClickLinkToReferencePageu0(e)
{
    self.location.href=$axure.globalVariableProvider.getLinkUrl('Home.html');
}

x = 0;
y = 56;
InsertAfterBegin(u0ann, "<img src='resources/images/newwindow.gif' id='u0PagePopup' style='cursor:pointer;position:absolute;z-index:500;left:" + x + ";top:" + y + "'>");

var u0PagePopup = document.getElementById('u0PagePopup');
if (bIE) u0PagePopup.attachEvent("onclick", u0PagePopupHandler);
else u0PagePopup.addEventListener("click", u0PagePopupHandler, true);

function u0PagePopupHandler(event)
{
    window.open($axure.globalVariableProvider.getLinkUrl('Home.html'));
}
