for(var i = 0; i < 116; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u86'] = 'center';gv_vAlignTable['u51'] = 'center';gv_vAlignTable['u102'] = 'top';gv_vAlignTable['u25'] = 'top';gv_vAlignTable['u16'] = 'top';gv_vAlignTable['u55'] = 'top';gv_vAlignTable['u46'] = 'center';gv_vAlignTable['u76'] = 'center';gv_vAlignTable['u107'] = 'top';gv_vAlignTable['u32'] = 'center';gv_vAlignTable['u23'] = 'top';gv_vAlignTable['u62'] = 'center';gv_vAlignTable['u7'] = 'center';gv_vAlignTable['u66'] = 'center';gv_vAlignTable['u112'] = 'top';gv_vAlignTable['u115'] = 'center';gv_vAlignTable['u104'] = 'top';gv_vAlignTable['u30'] = 'center';gv_vAlignTable['u60'] = 'center';gv_vAlignTable['u17'] = 'top';gv_vAlignTable['u64'] = 'center';gv_vAlignTable['u100'] = 'top';u19.tabIndex = 0;

u19.style.cursor = 'pointer';
$axure.eventManager.click('u19', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('2、影片列表頁_九宮格_.html');

}
});
gv_vAlignTable['u103'] = 'top';gv_vAlignTable['u97'] = 'top';gv_vAlignTable['u108'] = 'top';gv_vAlignTable['u15'] = 'top';gv_vAlignTable['u58'] = 'top';gv_vAlignTable['u92'] = 'center';gv_vAlignTable['u95'] = 'top';gv_vAlignTable['u22'] = 'top';gv_vAlignTable['u52'] = 'top';gv_vAlignTable['u0'] = 'top';gv_vAlignTable['u3'] = 'center';gv_vAlignTable['u68'] = 'center';gv_vAlignTable['u90'] = 'center';gv_vAlignTable['u73'] = 'top';gv_vAlignTable['u84'] = 'center';u20.tabIndex = 0;

u20.style.cursor = 'pointer';
$axure.eventManager.click('u20', function(e) {

if (true) {

    self.location.href="resources/reload.html#" + encodeURI($axure.globalVariableProvider.getLinkUrl($axure.pageData.url));

}
});
document.getElementById('u50_img').tabIndex = 0;

u50.style.cursor = 'pointer';
$axure.eventManager.click('u50', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('3-2、發問頁.html');

}
});
gv_vAlignTable['u106'] = 'top';gv_vAlignTable['u28'] = 'center';gv_vAlignTable['u24'] = 'top';gv_vAlignTable['u54'] = 'top';gv_vAlignTable['u99'] = 'top';gv_vAlignTable['u113'] = 'top';gv_vAlignTable['u39'] = 'center';gv_vAlignTable['u111'] = 'top';gv_vAlignTable['u78'] = 'center';gv_vAlignTable['u94'] = 'center';gv_vAlignTable['u96'] = 'top';document.getElementById('u61_img').tabIndex = 0;

u61.style.cursor = 'pointer';
$axure.eventManager.click('u61', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('3-2、發問頁.html');

}
});
gv_vAlignTable['u105'] = 'top';gv_vAlignTable['u109'] = 'top';gv_vAlignTable['u82'] = 'center';gv_vAlignTable['u5'] = 'center';gv_vAlignTable['u12'] = 'center';gv_vAlignTable['u9'] = 'center';gv_vAlignTable['u42'] = 'center';gv_vAlignTable['u33'] = 'top';gv_vAlignTable['u72'] = 'center';u18.tabIndex = 0;

u18.style.cursor = 'pointer';
$axure.eventManager.click('u18', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('1、影片首頁.html');

}
});
gv_vAlignTable['u48'] = 'center';gv_vAlignTable['u110'] = 'top';gv_vAlignTable['u88'] = 'center';gv_vAlignTable['u57'] = 'center';gv_vAlignTable['u101'] = 'top';gv_vAlignTable['u10'] = 'top';gv_vAlignTable['u40'] = 'top';gv_vAlignTable['u70'] = 'center';gv_vAlignTable['u44'] = 'center';gv_vAlignTable['u74'] = 'top';gv_vAlignTable['u98'] = 'top';gv_vAlignTable['u80'] = 'center';