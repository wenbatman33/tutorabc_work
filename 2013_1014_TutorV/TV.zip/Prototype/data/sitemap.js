﻿var sitemap = 

(function() {
    var _ = function() { var r={},a=arguments; for(var i=0; i<a.length; i+=2) r[a[i]]=a[i+1]; return r; }
    var _creator = function() { return _(b,[_(c,d,e,f,g,h,i,[_(c,j,e,f,g,k,i,[_(c,l,e,f,g,m),_(c,n,e,f,g,o),_(c,p,e,f,g,q)]),_(c,r,e,f,g,s,i,[_(c,t,e,f,g,u)]),_(c,v,e,f,g,w,i,[_(c,x,e,f,g,y),_(c,z,e,f,g,A)]),_(c,B,e,f,g,C,i,[_(c,D,e,f,g,E)]),_(c,F,e,f,g,G),_(c,H,e,f,g,I,i,[_(c,J,e,f,g,K),_(c,L,e,f,g,M),_(c,N,e,f,g,O),_(c,P,e,f,g,Q,i,[_(c,R,e,f,g,S),_(c,T,e,f,g,U)])]),_(c,V,e,f,g,W),_(c,X,e,f,g,Y,i,[_(c,Z,e,f,g,ba),_(c,bb,e,f,g,bc),_(c,bd,e,f,g,be)]),_(c,bf,e,f,g,bg)])]);}; 
var b="rootNodes",c="pageName",d="TutorV網站地圖",e="type",f="Wireframe",g="url",h="TutorV____.html",i="children",j="1、影片首頁",k="1、影片首頁.html",l="1-2、影片內頁-手機驗證",m="1-2、影片內頁-手機驗證.html",n="1-3、Live互動課程",o="1-3、Live互動課程.html",p="1-4、會員自行上傳影片",q="1-4、會員自行上傳影片.html",r="2、影片列表頁(九宮格)",s="2、影片列表頁_九宮格_.html",t="2-1、影片列表頁",u="2-1、影片列表頁.html",v="3、問答頁",w="3、問答頁.html",x="3-1、問題內頁",y="3-1、問題內頁.html",z="3-2、發問頁",A="3-2、發問頁.html",B="4、登入頁",C="4、登入頁.html",D="忘記密碼頁",E="忘記密碼頁.html",F="5、註冊頁",G="5、註冊頁.html",H="6、會員中心",I="6、會員中心.html",J="6-1、我的影片",K="6-1、我的影片.html",L="6-2、我的問答",M="6-2、我的問答.html",N="6-3、我的詞庫",O="6-3、我的詞庫.html",P="6-4、我的頻道",Q="6-4、我的頻道.html",R="6-4.1、創建個人Live頻道",S="6-4_1、創建個人Live頻道.html",T="6-4.2、上傳個人影片",U="6-4_2、上傳個人影片.html",V="7、點數購買中心(金流)",W="7、點數購買中心_金流_.html",X="8、Footer",Y="8_Footer.html",Z="8-1、隐私权条款",ba="8-1、隐私权条款.html",bb="8-2、安全性政策",bc="8-2、安全性政策.html",bd="8-3、服務條款",be="8-3、服務條款.html",bf="手機版首頁",bg="手機版首頁.html";
return _creator();
})();
