for(var i = 0; i < 286; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u115'] = 'top';gv_vAlignTable['u122'] = 'center';u21.tabIndex = 0;

u21.style.cursor = 'pointer';
$axure.eventManager.click('u21', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('1、影片首頁.html');

}
});
gv_vAlignTable['u32'] = 'top';gv_vAlignTable['u156'] = 'top';gv_vAlignTable['u207'] = 'top';gv_vAlignTable['u130'] = 'top';gv_vAlignTable['u236'] = 'center';gv_vAlignTable['u153'] = 'center';gv_vAlignTable['u226'] = 'top';gv_vAlignTable['u222'] = 'center';gv_vAlignTable['u135'] = 'top';gv_vAlignTable['u151'] = 'top';gv_vAlignTable['u212'] = 'top';gv_vAlignTable['u42'] = 'center';gv_vAlignTable['u256'] = 'center';gv_vAlignTable['u101'] = 'top';gv_vAlignTable['u27'] = 'top';gv_vAlignTable['u52'] = 'top';gv_vAlignTable['u20'] = 'top';gv_vAlignTable['u67'] = 'center';gv_vAlignTable['u65'] = 'top';gv_vAlignTable['u120'] = 'center';gv_vAlignTable['u6'] = 'center';document.getElementById('u247_img').tabIndex = 0;

u247.style.cursor = 'pointer';
$axure.eventManager.click('u247', function(e) {

if (true) {

}
});
gv_vAlignTable['u238'] = 'center';gv_vAlignTable['u75'] = 'center';gv_vAlignTable['u133'] = 'top';gv_vAlignTable['u200'] = 'top';gv_vAlignTable['u34'] = 'center';gv_vAlignTable['u89'] = 'center';gv_vAlignTable['u266'] = 'center';gv_vAlignTable['u47'] = 'center';gv_vAlignTable['u213'] = 'top';gv_vAlignTable['u185'] = 'center';gv_vAlignTable['u264'] = 'top';gv_vAlignTable['u103'] = 'center';gv_vAlignTable['u164'] = 'center';gv_vAlignTable['u258'] = 'top';gv_vAlignTable['u233'] = 'center';gv_vAlignTable['u112'] = 'top';gv_vAlignTable['u78'] = 'top';gv_vAlignTable['u276'] = 'top';gv_vAlignTable['u231'] = 'top';gv_vAlignTable['u283'] = 'center';gv_vAlignTable['u191'] = 'top';gv_vAlignTable['u125'] = 'top';gv_vAlignTable['u280'] = 'center';document.getElementById('u41_img').tabIndex = 0;

u41.style.cursor = 'pointer';
$axure.eventManager.click('u41', function(e) {

if (true) {

	SetPanelState('u43', 'pd0u43','none','',500,'none','',500);

}
});
gv_vAlignTable['u172'] = 'center';gv_vAlignTable['u54'] = 'center';gv_vAlignTable['u118'] = 'top';gv_vAlignTable['u197'] = 'top';gv_vAlignTable['u38'] = 'center';gv_vAlignTable['u176'] = 'center';u267.tabIndex = 0;

u267.style.cursor = 'pointer';
$axure.eventManager.click('u267', function(e) {

if (true) {

	SetPanelVisibility('u246','hidden','none',500);

}
});
gv_vAlignTable['u26'] = 'top';gv_vAlignTable['u174'] = 'top';gv_vAlignTable['u128'] = 'top';gv_vAlignTable['u254'] = 'center';gv_vAlignTable['u51'] = 'center';gv_vAlignTable['u241'] = 'center';gv_vAlignTable['u252'] = 'center';gv_vAlignTable['u10'] = 'center';document.getElementById('u265_img').tabIndex = 0;

u265.style.cursor = 'pointer';
$axure.eventManager.click('u265', function(e) {

if (true) {

	self.location.href='#';

}
});
gv_vAlignTable['u100'] = 'center';u23.tabIndex = 0;

u23.style.cursor = 'pointer';
$axure.eventManager.click('u23', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('3、問答頁.html');

}
});
gv_vAlignTable['u144'] = 'top';gv_vAlignTable['u202'] = 'center';gv_vAlignTable['u166'] = 'center';gv_vAlignTable['u36'] = 'top';gv_vAlignTable['u95'] = 'center';gv_vAlignTable['u61'] = 'top';gv_vAlignTable['u195'] = 'top';gv_vAlignTable['u158'] = 'center';gv_vAlignTable['u223'] = 'top';gv_vAlignTable['u114'] = 'center';document.getElementById('u33_img').tabIndex = 0;

u33.style.cursor = 'pointer';
$axure.eventManager.click('u33', function(e) {

if (true) {

	SetPanelVisibility('u140','hidden','none',500);

}
});
gv_vAlignTable['u160'] = 'center';gv_vAlignTable['u92'] = 'center';gv_vAlignTable['u126'] = 'top';gv_vAlignTable['u71'] = 'center';gv_vAlignTable['u181'] = 'center';gv_vAlignTable['u198'] = 'top';gv_vAlignTable['u98'] = 'center';gv_vAlignTable['u214'] = 'top';gv_vAlignTable['u127'] = 'top';gv_vAlignTable['u225'] = 'center';gv_vAlignTable['u56'] = 'center';gv_vAlignTable['u150'] = 'center';gv_vAlignTable['u187'] = 'center';gv_vAlignTable['u142'] = 'center';gv_vAlignTable['u106'] = 'center';gv_vAlignTable['u168'] = 'top';gv_vAlignTable['u40'] = 'center';gv_vAlignTable['u87'] = 'top';gv_vAlignTable['u193'] = 'center';gv_vAlignTable['u104'] = 'top';gv_vAlignTable['u269'] = 'center';document.getElementById('u192_img').tabIndex = 0;

u192.style.cursor = 'pointer';
$axure.eventManager.click('u192', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('5、註冊頁.html');

}
});
gv_vAlignTable['u250'] = 'center';gv_vAlignTable['u211'] = 'center';gv_vAlignTable['u19'] = 'top';gv_vAlignTable['u242'] = 'top';gv_vAlignTable['u155'] = 'center';gv_vAlignTable['u206'] = 'center';gv_vAlignTable['u109'] = 'center';gv_vAlignTable['u84'] = 'top';gv_vAlignTable['u239'] = 'top';document.getElementById('u63_img').tabIndex = 0;

u63.style.cursor = 'pointer';
$axure.eventManager.click('u63', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('3-2、發問頁.html');

}
});
gv_vAlignTable['u260'] = 'center';gv_vAlignTable['u273'] = 'top';gv_vAlignTable['u170'] = 'center';gv_vAlignTable['u271'] = 'center';gv_vAlignTable['u81'] = 'top';gv_vAlignTable['u228'] = 'center';gv_vAlignTable['u209'] = 'center';gv_vAlignTable['u60'] = 'top';gv_vAlignTable['u190'] = 'center';gv_vAlignTable['u73'] = 'top';gv_vAlignTable['u69'] = 'center';gv_vAlignTable['u234'] = 'top';gv_vAlignTable['u147'] = 'center';gv_vAlignTable['u131'] = 'top';u277.tabIndex = 0;

u277.style.cursor = 'pointer';
$axure.eventManager.click('u277', function(e) {

if (true) {

	SetPanelVisibility('u246','hidden','none',500);

}
});
gv_vAlignTable['u64'] = 'center';gv_vAlignTable['u272'] = 'top';gv_vAlignTable['u230'] = 'center';gv_vAlignTable['u162'] = 'top';gv_vAlignTable['u204'] = 'center';gv_vAlignTable['u117'] = 'center';gv_vAlignTable['u13'] = 'top';gv_vAlignTable['u274'] = 'top';document.getElementById('u259_img').tabIndex = 0;

u259.style.cursor = 'pointer';
$axure.eventManager.click('u259', function(e) {

if (true) {

	self.location.href='#';

}
});
gv_vAlignTable['u132'] = 'top';gv_vAlignTable['u262'] = 'center';gv_vAlignTable['u217'] = 'center';gv_vAlignTable['u129'] = 'top';gv_vAlignTable['u86'] = 'center';gv_vAlignTable['u58'] = 'top';gv_vAlignTable['u183'] = 'center';gv_vAlignTable['u111'] = 'center';gv_vAlignTable['u285'] = 'center';gv_vAlignTable['u31'] = 'center';gv_vAlignTable['u83'] = 'center';gv_vAlignTable['u275'] = 'top';gv_vAlignTable['u178'] = 'center';gv_vAlignTable['u8'] = 'center';gv_vAlignTable['u3'] = 'top';gv_vAlignTable['u96'] = 'top';u196.tabIndex = 0;

u196.style.cursor = 'pointer';
$axure.eventManager.click('u196', function(e) {

if (true) {

	SetPanelVisibility('u188','hidden','none',500);

}
});
gv_vAlignTable['u196'] = 'top';gv_vAlignTable['u15'] = 'center';gv_vAlignTable['u49'] = 'center';gv_vAlignTable['u124'] = 'center';gv_vAlignTable['u80'] = 'center';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u93'] = 'top';gv_vAlignTable['u145'] = 'top';gv_vAlignTable['u12'] = 'center';gv_vAlignTable['u199'] = 'top';gv_vAlignTable['u281'] = 'top';gv_vAlignTable['u25'] = 'top';gv_vAlignTable['u59'] = 'top';gv_vAlignTable['u137'] = 'top';gv_vAlignTable['u244'] = 'center';gv_vAlignTable['u90'] = 'top';gv_vAlignTable['u18'] = 'top';gv_vAlignTable['u248'] = 'center';gv_vAlignTable['u45'] = 'center';gv_vAlignTable['u77'] = 'center';u22.tabIndex = 0;

u22.style.cursor = 'pointer';
$axure.eventManager.click('u22', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('2、影片列表頁_九宮格_.html');

}
});
gv_vAlignTable['u143'] = 'top';gv_vAlignTable['u220'] = 'top';gv_vAlignTable['u107'] = 'top';gv_vAlignTable['u136'] = 'top';gv_vAlignTable['u218'] = 'top';gv_vAlignTable['u28'] = 'top';