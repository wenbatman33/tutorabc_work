for(var i = 0; i < 219; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

if (true) {

}

});
gv_vAlignTable['u115'] = 'center';gv_vAlignTable['u122'] = 'center';gv_vAlignTable['u21'] = 'top';gv_vAlignTable['u130'] = 'top';gv_vAlignTable['u79'] = 'center';gv_vAlignTable['u153'] = 'center';gv_vAlignTable['u140'] = 'center';gv_vAlignTable['u135'] = 'center';gv_vAlignTable['u151'] = 'center';gv_vAlignTable['u212'] = 'top';gv_vAlignTable['u42'] = 'center';gv_vAlignTable['u159'] = 'center';gv_vAlignTable['u55'] = 'top';gv_vAlignTable['u101'] = 'center';document.getElementById('u186_img').tabIndex = 0;

u186.style.cursor = 'pointer';
$axure.eventManager.click('u186', function(e) {

if (true) {

	SetPanelVisibility('u185','hidden','none',500);

}
});
gv_vAlignTable['u105'] = 'center';gv_vAlignTable['u138'] = 'center';gv_vAlignTable['u52'] = 'top';gv_vAlignTable['u67'] = 'center';gv_vAlignTable['u65'] = 'top';gv_vAlignTable['u120'] = 'center';gv_vAlignTable['u110'] = 'center';gv_vAlignTable['u6'] = 'top';gv_vAlignTable['u108'] = 'top';gv_vAlignTable['u37'] = 'center';gv_vAlignTable['u62'] = 'top';gv_vAlignTable['u141'] = 'top';gv_vAlignTable['u11'] = 'center';gv_vAlignTable['u75'] = 'top';gv_vAlignTable['u133'] = 'top';u200.tabIndex = 0;

u200.style.cursor = 'pointer';
$axure.eventManager.click('u200', function(e) {

if (true) {

	SetPanelVisibility('u185','hidden','none',500);

}
});
gv_vAlignTable['u68'] = 'top';gv_vAlignTable['u39'] = 'center';gv_vAlignTable['u47'] = 'center';gv_vAlignTable['u213'] = 'top';gv_vAlignTable['u184'] = 'center';gv_vAlignTable['u72'] = 'top';gv_vAlignTable['u103'] = 'center';gv_vAlignTable['u99'] = 'center';gv_vAlignTable['u112'] = 'center';gv_vAlignTable['u44'] = 'center';gv_vAlignTable['u179'] = 'top';gv_vAlignTable['u57'] = 'center';gv_vAlignTable['u191'] = 'center';gv_vAlignTable['u16'] = 'top';gv_vAlignTable['u203'] = 'center';gv_vAlignTable['u125'] = 'center';gv_vAlignTable['u149'] = 'center';gv_vAlignTable['u54'] = 'center';gv_vAlignTable['u118'] = 'center';gv_vAlignTable['u88'] = 'center';gv_vAlignTable['u189'] = 'center';gv_vAlignTable['u176'] = 'center';u26.tabIndex = 0;

u26.style.cursor = 'pointer';
$axure.eventManager.click('u26', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('3、問答頁.html');

}
});
gv_vAlignTable['u128'] = 'center';gv_vAlignTable['u85'] = 'center';gv_vAlignTable['u51'] = 'center';gv_vAlignTable['u23'] = 'top';gv_vAlignTable['u144'] = 'top';gv_vAlignTable['u166'] = 'center';gv_vAlignTable['u82'] = 'center';gv_vAlignTable['u30'] = 'top';gv_vAlignTable['u95'] = 'top';gv_vAlignTable['u61'] = 'center';gv_vAlignTable['u116'] = 'top';gv_vAlignTable['u74'] = 'center';gv_vAlignTable['u123'] = 'top';gv_vAlignTable['u157'] = 'center';gv_vAlignTable['u92'] = 'center';gv_vAlignTable['u126'] = 'top';gv_vAlignTable['u71'] = 'center';gv_vAlignTable['u181'] = 'center';gv_vAlignTable['u198'] = 'center';gv_vAlignTable['u5'] = 'center';gv_vAlignTable['u169'] = 'top';gv_vAlignTable['u187'] = 'center';gv_vAlignTable['u168'] = 'center';gv_vAlignTable['u40'] = 'top';gv_vAlignTable['u192'] = 'top';gv_vAlignTable['u211'] = 'top';gv_vAlignTable['u155'] = 'center';gv_vAlignTable['u206'] = 'center';gv_vAlignTable['u97'] = 'center';document.getElementById('u170_img').tabIndex = 0;

u170.style.cursor = 'pointer';
$axure.eventManager.click('u170', function(e) {

if (true) {

}
});
document.getElementById('u177_img').tabIndex = 0;

u177.style.cursor = 'pointer';
$axure.eventManager.click('u177', function(e) {

if (true) {

}
});
gv_vAlignTable['u209'] = 'center';gv_vAlignTable['u94'] = 'center';gv_vAlignTable['u9'] = 'center';gv_vAlignTable['u69'] = 'top';gv_vAlignTable['u147'] = 'top';gv_vAlignTable['u163'] = 'center';gv_vAlignTable['u64'] = 'center';u24.tabIndex = 0;

u24.style.cursor = 'pointer';
$axure.eventManager.click('u24', function(e) {

if (true) {

    self.location.href="resources/reload.html#" + encodeURI($axure.globalVariableProvider.getLinkUrl($axure.pageData.url));

}
});
u204.tabIndex = 0;

u204.style.cursor = 'pointer';
$axure.eventManager.click('u204', function(e) {

if (true) {

	SetPanelState('u185', 'pd0u185','none','',500,'none','',500);

}
});
gv_vAlignTable['u210'] = 'top';gv_vAlignTable['u13'] = 'center';gv_vAlignTable['u113'] = 'top';gv_vAlignTable['u29'] = 'top';gv_vAlignTable['u132'] = 'center';gv_vAlignTable['u217'] = 'center';gv_vAlignTable['u129'] = 'top';gv_vAlignTable['u86'] = 'top';gv_vAlignTable['u173'] = 'center';gv_vAlignTable['u171'] = 'center';gv_vAlignTable['u31'] = 'top';gv_vAlignTable['u83'] = 'top';gv_vAlignTable['u178'] = 'center';gv_vAlignTable['u3'] = 'center';gv_vAlignTable['u146'] = 'center';gv_vAlignTable['u196'] = 'center';gv_vAlignTable['u15'] = 'center';gv_vAlignTable['u49'] = 'center';gv_vAlignTable['u80'] = 'top';gv_vAlignTable['u1'] = 'center';document.getElementById('u167_img').tabIndex = 0;

u167.style.cursor = 'pointer';
$axure.eventManager.click('u167', function(e) {

if (true) {

}
});
u201.tabIndex = 0;

u201.style.cursor = 'pointer';
$axure.eventManager.click('u201', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('1-2、影片內頁-手機驗證.html');

}
});
gv_vAlignTable['u199'] = 'top';u25.tabIndex = 0;

u25.style.cursor = 'pointer';
$axure.eventManager.click('u25', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('2、影片列表頁_九宮格_.html');

}
});
gv_vAlignTable['u59'] = 'center';gv_vAlignTable['u215'] = 'center';gv_vAlignTable['u90'] = 'center';gv_vAlignTable['u18'] = 'center';gv_vAlignTable['u161'] = 'center';gv_vAlignTable['u45'] = 'top';gv_vAlignTable['u77'] = 'center';gv_vAlignTable['u22'] = 'top';gv_vAlignTable['u143'] = 'center';gv_vAlignTable['u107'] = 'center';gv_vAlignTable['u35'] = 'center';gv_vAlignTable['u136'] = 'top';u218.tabIndex = 0;

u218.style.cursor = 'pointer';
$axure.eventManager.click('u218', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('1-2、影片內頁-手機驗證.html');

}
});
document.getElementById('u180_img').tabIndex = 0;

u180.style.cursor = 'pointer';
$axure.eventManager.click('u180', function(e) {

if (true) {

}
});
gv_vAlignTable['u28'] = 'top';gv_vAlignTable['u194'] = 'center';